import OshiichiIntegratedApp from '@/components/OshiichiIntegratedApp'

export default function Home() {
  return <OshiichiIntegratedApp />
}
